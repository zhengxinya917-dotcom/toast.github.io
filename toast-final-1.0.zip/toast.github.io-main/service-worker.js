const CACHE_NAME = "toast-v2";

const FILES = [
    "./",
    "./index.html",
    "./manifest.json",
    "./icons/icon-192.png",
    "./icons/icon-512.png"
];

self.addEventListener("install", event=>{
    event.waitUntil(caches.open(CACHE_NAME).then(cache=>cache.addAll(FILES)));
});

self.addEventListener("activate", event=>{
    event.waitUntil(
        caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE_NAME).map(k=>caches.delete(k))))
    );
});

self.addEventListener("fetch", event=>{
    event.respondWith(caches.match(event.request).then(r=>r||fetch(event.request)));
});

self.addEventListener("notificationclick", event=>{
    event.notification.close();
    event.waitUntil(clients.openWindow("./"));
});

self.addEventListener("push", event=>{
    const data = event.data ? event.data.json() : {};
    event.waitUntil(self.registration.showNotification(data.title||"Toast", {
        body:data.body||"你有新的提醒",
        icon:data.icon||"icons/icon-512.png"
    }));
});
